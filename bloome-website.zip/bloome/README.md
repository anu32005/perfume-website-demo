# 🌸 BLOOME — Natural Perfumes Demo Website

A fully responsive, animated e-commerce demo for a natural perfume brand. Built with pure HTML, CSS & JavaScript — no frameworks, no dependencies, no build step.

## 🔗 Live Demo

> Deploy to GitHub Pages and paste your link here:  
> `https://yourusername.github.io/bloome/`

---

## 📁 File Structure

```
bloome/
├── index.html              ← Homepage with animated spring tree
├── css/
│   └── page.css            ← Shared styles for product pages
├── js/
│   └── shared.js           ← Cart, wishlist, petals, heart burst
└── pages/
    ├── her.html            ← For Her (7 products)
    ├── him.html            ← For Him (7 products)
    ├── unisex.html         ← Unisex (7 products)
    └── bestsellers.html    ← Bestsellers with ratings
```

---

## ✨ Features

- 🌸 **Spring Petal Animation** — 60+ canvas petals fall when adding to cart
- 💖 **Heart Burst** — Heart explodes on wishlisting
- 🌲 **Animated Hero Tree** — Sways and blooms on cart actions
- 🛒 **Live Cart Counter** — Persists across pages via localStorage
- 🌺 **Fragrance Note Filter** — Filter products by jasmine, oud, rose, sandalwood, vanilla, cedar, white musk
- 🏷️ **Category Tabs** — Her / Him / Unisex / Bestsellers pages
- ⭐ **Star Ratings** — On bestsellers page
- 📱 **Fully Responsive** — Mobile-first design
- 🎨 **Bright Nature Palette** — Greens, rose, amber, cream

---

## 🚀 Deploy to GitHub Pages

1. Create a new repo on GitHub (e.g. `bloome`)
2. Upload all files maintaining the folder structure
3. Go to **Settings → Pages → Source → main branch → / (root)**
4. Your site will be live at `https://yourusername.github.io/bloome/`

---

## 🛠 How to Use

Simply open `index.html` in any browser. No installation needed.

---

*© 2026 Bloome Natural Perfumes — Demo Project*
