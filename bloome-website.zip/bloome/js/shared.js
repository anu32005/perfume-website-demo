// ===== BLOOME SHARED JS =====

let cartCount = parseInt(localStorage.getItem('bloome_cart')) || 0;
let wishCount = parseInt(localStorage.getItem('bloome_wish')) || 0;

function updateBadges() {
  const cb = document.getElementById('cartBadge');
  const wb = document.getElementById('wishBadge');
  if (cb) { cb.textContent = cartCount; cb.classList.add('bump'); setTimeout(() => cb.classList.remove('bump'), 400); }
  if (wb) { wb.textContent = wishCount; }
  localStorage.setItem('bloome_cart', cartCount);
  localStorage.setItem('bloome_wish', wishCount);
}

function addToCart(e) {
  e?.stopPropagation();
  cartCount++;
  updateBadges();
  showPetals();
  showCartBurst();
  showToast('🌸 Added to your bag!');
  bloomTree();
}

function addToWish(e) {
  e?.stopPropagation();
  wishCount++;
  updateBadges();
  triggerHeart();
  showToast('💖 Added to wishlist!', '#e63946');
}

function triggerHeart() {
  const h = document.getElementById('heartBurst');
  if (!h) return;
  h.classList.remove('active');
  void h.offsetWidth;
  h.classList.add('active');
  setTimeout(() => h.classList.remove('active'), 1400);
}

function showCartBurst() {
  const c = document.getElementById('cartBurst');
  if (!c) return;
  const emojis = ['🌸','🌺','🌷','🌼','🪷','🌻'];
  c.textContent = emojis[Math.floor(Math.random() * emojis.length)];
  c.classList.remove('active');
  void c.offsetWidth;
  c.classList.add('active');
  setTimeout(() => c.classList.remove('active'), 1000);
}

function showToast(msg, bg) {
  const t = document.getElementById('toast');
  if (!t) return;
  t.textContent = msg;
  if (bg) t.style.background = bg; else t.style.background = '';
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 2400);
}

function bloomTree() {
  const tree = document.getElementById('heroTree');
  if (!tree) return;
  tree.classList.add('bloom');
  setTimeout(() => tree.classList.remove('bloom'), 800);
}

// ===== PETAL CANVAS =====
function showPetals() {
  const canvas = document.getElementById('petalCanvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;

  const petalColors = ['#f48fb1','#fce4ec','#c8e6c9','#fff9c4','#ffccbc','#e1bee7','#f8bbd9','#a5d6a7','#ffecb3','#ffe0f0','#d1fae5'];
  const shapes = ['petal','circle','star'];
  
  let petals = [];
  const COUNT = 65;
  
  for (let i = 0; i < COUNT; i++) {
    petals.push({
      x: Math.random() * canvas.width,
      y: -20 - Math.random() * 200,
      size: 8 + Math.random() * 18,
      color: petalColors[Math.floor(Math.random() * petalColors.length)],
      vx: (Math.random() - 0.5) * 2.5,
      vy: 1.5 + Math.random() * 3,
      rot: Math.random() * 360,
      rotV: (Math.random() - 0.5) * 6,
      shape: shapes[Math.floor(Math.random() * shapes.length)],
      opacity: 0.7 + Math.random() * 0.3,
      delay: Math.random() * 80
    });
  }

  let frame = 0;
  function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    let alive = false;
    petals.forEach(p => {
      if (frame < p.delay) { alive = true; return; }
      p.x += p.vx + Math.sin(frame * 0.02 + p.delay) * 0.5;
      p.y += p.vy;
      p.rot += p.rotV;
      p.vy += 0.015;
      ctx.save();
      ctx.globalAlpha = p.opacity * Math.max(0, 1 - p.y / canvas.height);
      ctx.translate(p.x, p.y);
      ctx.rotate(p.rot * Math.PI / 180);
      ctx.fillStyle = p.color;
      if (p.shape === 'petal') {
        ctx.beginPath();
        ctx.ellipse(0, 0, p.size * 0.5, p.size, 0, 0, Math.PI * 2);
        ctx.fill();
      } else if (p.shape === 'circle') {
        ctx.beginPath();
        ctx.arc(0, 0, p.size * 0.5, 0, Math.PI * 2);
        ctx.fill();
      } else {
        // star
        ctx.beginPath();
        for (let s = 0; s < 5; s++) {
          const angle = (s / 5) * Math.PI * 2 - Math.PI / 2;
          const innerAngle = angle + Math.PI / 5;
          if (s === 0) ctx.moveTo(Math.cos(angle) * p.size * 0.5, Math.sin(angle) * p.size * 0.5);
          else ctx.lineTo(Math.cos(angle) * p.size * 0.5, Math.sin(angle) * p.size * 0.5);
          ctx.lineTo(Math.cos(innerAngle) * p.size * 0.22, Math.sin(innerAngle) * p.size * 0.22);
        }
        ctx.closePath();
        ctx.fill();
      }
      ctx.restore();
      if (p.y < canvas.height + 50) alive = true;
    });
    frame++;
    if (alive && frame < 300) requestAnimationFrame(draw);
    else ctx.clearRect(0, 0, canvas.width, canvas.height);
  }
  draw();
}

// Init on load
window.addEventListener('DOMContentLoaded', () => {
  document.getElementById('cartBadge').textContent = cartCount;
  document.getElementById('wishBadge').textContent = wishCount;
});
